# MX-Test: candidatos para el mod y parche 0073 pendiente

| Archivo | Destino en el repo | Acción |
|---|---|---|
| .github/workflows/candidate.yml | .github/workflows/candidate.yml | AÑADIR |
| patches/pendientes/0073-...patch | patches/pendientes/ | AÑADIR (no se aplica) |
| patches/client/0073-...patch | — | BORRAR (movido a pendientes) |

Antes de fusionar, configurar en el repo de MX-Test:
1. Secreto MOD_DISPATCH_TOKEN: PAT de grano fino con "Contents: write" sobre MindustryOpenWorldTest.
2. En el repo del mod, secreto MX_STATUS_TOKEN: PAT de grano fino con "Commit statuses: write" sobre MX-Test.
3. Protección de la rama main de MX-Test: exigir el contexto de estado "mod-compat". Sin esto, un PR puede fusionarse aunque el mod falle.

Arc: se mantienen solo patches/arc/0005 (ventana SDL para el loader). Los demás parches de Arc ya están borrados.

Nada de esto se ha compilado ni ejecutado (decisión de esta sesión; lo verificará GitHub Actions).
